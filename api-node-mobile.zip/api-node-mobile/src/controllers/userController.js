const express = require("express");
const UserService = require("../services/UserService");

const router = express.Router();

router.get("/", async (req, res) =>{
    try{
        const users = await UserService.getUsers();
        res.json(users);
    }
    catch(error){
        res.status(400).json({error: error.massage});
    }
})

module.exports = router;