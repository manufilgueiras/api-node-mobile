const bcrypt = require("bcrypt");
const userRepository = require("../repositories/userRepository");

const SECRET_KEY = "SUACHAVESECRETA";

class UserService{
    async register(username, password, email){
        if(this.getByUserName(username)){
            throw new Error("Usuário já cadastrado.")
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const user = await userRepository.createUser({username, email, password: hashedPassword});
        return user;
    }

    async getByUserName(username){
        return await userRepository.findByUserName(username);
    }

    async login(username, password){
        const user = this.getByUserName(username);
        if(!user){
            throw new Error("Usuário ou senha incorretos.")
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const isPasswordValid = await bcrypt.compare(hashedPassword, user.password);
        if(!isPasswordValid){
            throw new Error("Usuário ou senha incorretos.")
        }

        return true;
    }  

    async getUsers(){
        return await userRepository.findAll();
    }
}

module.exports = new UserService();